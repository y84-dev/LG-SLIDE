
module.exports = {
  Query: {
    slideWidget(_, { settings }) {
      return { text: settings.text, className: settings.className };
    }
  }
};
