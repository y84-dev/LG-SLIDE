import React from 'react';
import PropTypes from 'prop-types';

export default function SlideWidget({ slideWidget: { text, className }}) {
  return (
    <div className={className}>
      <h1>{text}</h1>
    </div>
  );
}

SlideWidget.propTypes = {
  text: PropTypes.string,
  className: PropTypes.string
};

SlideWidget.defaultProps = {
  text: '',
  className: ''
};

export const query = `
  query Query($settings: JSON) {
    slideWidget(settings: $settings) {
      text
      className
    }
  }
`;

export const variables = `{
  settings: getWidgetSetting()
}`;
