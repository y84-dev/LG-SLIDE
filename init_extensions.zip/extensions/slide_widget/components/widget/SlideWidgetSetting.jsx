import React from 'react';
import PropTypes from 'prop-types';
import { Field } from '@components/common/form/Field';

export default function SlideWidgetSetting({
  slideWidget: { text, className }
}) {
  return (
    <div>
        <p>Configure your greeting widget</p>
        <Field
            type="text"
            name="settings[className]"
            label="Custom css classes"
            value={className}
            placeholder="Custom css classes"
        />
        <Field
            type="textarea"
            name="settings[text]"
            label="Greeting text"
            value={text}
        />
    </div>
  );
}

SlideWidgetSetting.propTypes = {
  slideWidget: PropTypes.shape({
    text: PropTypes.string,
    className: PropTypes.string
  })
};

SlideWidgetSetting.defaultProps = {
  slideWidget: {
    text: 'Hello, welcome to our store!',
    className: ''
  }
};

export const query = `
  query Query($settings: JSON) {
    slideWidget(settings: $settings) {
      text
      className
    }
  }
`;

export const variables = `{
  settings: getWidgetSetting()
}`;
